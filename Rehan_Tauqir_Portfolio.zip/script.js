const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("visible");
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

const cursor = document.querySelector(".cursor");
if (window.matchMedia("(pointer:fine)").matches) {
  cursor.style.cssText = "position:fixed;width:8px;height:8px;border-radius:50%;background:#b9ff3c;pointer-events:none;z-index:99;transform:translate(-50%,-50%);mix-blend-mode:screen;transition:transform .08s linear";
  window.addEventListener("mousemove", e => {
    cursor.style.left = e.clientX + "px";
    cursor.style.top = e.clientY + "px";
  });
}

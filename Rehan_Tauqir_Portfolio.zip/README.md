# Rehan Tauqir Nawaz — Portfolio

A dark, interactive personal portfolio for an Information Systems student based in Riga, Latvia.

## Files
- `index.html` — portfolio structure/content
- `style.css` — responsive visual design
- `script.js` — scroll reveal and cursor interaction

## Run
Open `index.html` in a browser, or serve the folder with any local web server.

## Important
Arduino is intentionally not included.
